# Interaction-based-robot-for-MIU-admission-office
  robot is designed to replace some tasks done by humans and to do them in a faster and efficient way.
